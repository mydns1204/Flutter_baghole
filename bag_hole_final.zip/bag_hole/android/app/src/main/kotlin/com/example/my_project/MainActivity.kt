package com.mycompany.baghole

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
